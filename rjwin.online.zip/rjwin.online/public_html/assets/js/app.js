$(document).ready(function()
{

$(".show-icon").click(function(event){
   let inputParent =  $(event.target).parent().children()[1];
   if($(event.target).attr("data") == "hide")
   {
      $(event.target).attr("data","show");
      $(inputParent).attr("type","text");
     $(event.target).css("filter","invert(0)");
   }
   else{
      $(event.target).attr("data","hide");
      $(inputParent).attr("type","password");
     $(event.target).css("filter","invert(0.5)");
   }
});


if($("input[name='mobile']")[0] != undefined)
{
$("input[name='mobile']")[0].addEventListener("input",function()
   {
       let value = parseInt(this.value);
       if(isNaN(value))
      {
      this.value = "";
      }
     else{
      this.value = value;
      }
   });
}
$(".back-btn").click(function()
{
   history.back();
});
});
function Alert(msg,icon)
{
    Swal.fire({
        icon:icon,
        html: `<p class='popUp-text'>${msg}</p>`
    });
}
function confirm(btn)
{
   Swal.fire({
  text: "Are you sure?",
  icon: "warning",
  showCancelButton: true,
  confirmButtonColor: "#3085d6",
  cancelButtonColor: "#d33",
  confirmButtonText:btn
}).then((result) => {
  if (result.isConfirmed) {
    window.location.href = baseUrl+"logout";
  }
});
}