
$(document).ready(function()
{
   
let userId = $(".profile-img").attr("data");
let requestStatus = false;
let receiveId = window.location.href.replace(baseUrl+"chats/","");
let count = 0;
let AllMsg;

let deleteMsg = [];

Array.from($(".msg-container>div")).forEach((element,index)=>{
element.addEventListener("mousedown",function()
{
    countTime();

    if($(".msg-container").attr("selectData"))
    {
    	$(element).css("bacground","blue");
    }
});

});



$(".file-form").submit(function(event)
{
   event.preventDefault();
});





$(".select").click(function()
{
   if($(".msg-container").attr("selectData") == "false")
   {
          $(".msg-container").attr("selectData","true");
          $(".select").attr("src",baseUrl+"assets/icons/close.svg");
          $(".overlay").show();
          ClickAndSelect();
   }
   else{
          $(".msg-container").attr("selectData","false");
          $(".select").attr("src",baseUrl+"assets/icons/select.svg");
          $(".overlay").hide();
          $(".msg-container>*").css("background","none");
          $(".msg-container>*").attr("select","false");
          $(".delete").hide();
   }
});





function ClickAndSelect()
{
     AllMsg = $(".msg-container>*>.overlay");
    if($(".msg-container").attr("selectData") == "true")
      {
    Array.from(AllMsg).forEach((element,index)=>{
          element.addEventListener("click",select);
    });
    }
}

function select()
{
    if($(this).parent().attr("select") == "false")
    {
         if($(this).parent().attr("class") == "sent-msg-box")
         {
            $(this).parent().css("background","rgb(77, 140, 249)");
            $(this).parent().attr("select","true");
            $(this).parent().attr("delete",`${deleteMsg.length}`);
            deleteMsg.push($(this).parent().attr("msgId"));
         }
         else{
            $(this).parent().css("background","rgb(0, 255, 216)");
            $(this).parent().attr("select","true");
            $(this).parent().attr("delete",`${deleteMsg.length}`);
            deleteMsg.push($(this).parent().attr("msgId"));
         }
    }
    else{
            $(this).parent().css("background","none");
            $(this).parent().attr("select","false");
            if(deleteMsg.length == 1)
            {
            deleteMsg.splice(parseInt($(this).parent().attr("delete")),parseInt($(this).parent().attr("delete"))+1);              
            }
            else{
            deleteMsg.splice(parseInt($(this).parent().attr("delete")),parseInt($(this).parent().attr("delete")));
            }
            $(this).parent().attr("delete","-1");

    }
    deleteIcon(deleteMsg);
}



function deleteIcon(deleteMsg)
{
     if(deleteMsg.length == 0)
     {
        $(".delete").hide();
     }
     else{
        $(".delete").show();
     }
}

$(".delete").click(function()
{
    Swal.fire({
  text: "Are you sure?",
  icon: "warning",
  showCancelButton: true,
  confirmButtonColor: "#3085d6",
  cancelButtonColor: "#d33",
  confirmButtonText:"delete"
}).then((result) => {
  if (result.isConfirmed) {
    $(".loader").css("display","flex");
    deleteDomElement(deleteMsg);
    let msgId = deleteMsg.toString();

    let data = {Id:msgId};

    $.ajax({
     url:baseUrl+"delete-msg",
     type:"post",
     data:data,
     success:function(data) 
     {
           if(data == 1)
          {
            $(".msg-container").attr("selectData","false");
            $(".select").attr("src",baseUrl+"assets/icons/select.svg");
            $(".overlay").hide();
            $(".msg-container>*").css("background","none");
            $(".msg-container>*").attr("select","false");
            $(".delete").hide();
            deleteMsg = [];
          }
          $(".loader").hide();
     }
    });
}
});
});


$(".file-form input")[0].addEventListener("change",function(){
  
   $(".loader").css("display","flex");
   let myForm = document.querySelector(".file-form");

   let getData = new FormData(myForm);

   getData.append("id",receiveId);

   $.ajax({
     url:baseUrl+"send-file-msg",
     type:"post",
     data:getData,
     cache:false,
     processData:false,
     contentType:false,
     success:function(data) 
     {
          
     },
     error:function(error) 
     {
        console.log(error);
     }

});
});



// text massage Send

$(".sent-msg").click(function()
{
    let textInputValue = $(".sent-container input[type='text']").val();

    if(textInputValue.trim() != "")
    {
        sendTextMsg(textInputValue);
        $(".sent-container input[type='text']").val("");
    }
});


// text msg ajax request
function sendTextMsg(msg)
{
     $(".loader").css("display","flex");
    let data = {id:receiveId,text:msg};

    $.ajax({
     url:baseUrl+"send-text-msg",
     type:"post",
     data:data,
     success:function(data) 
     {
         
     },
     error:function(error) 
     {
        
     }
    });
}



function deleteDomElement(id)
{
      for(let i=0;i<id.length;i++)
      {
        let sel = `.msg-container>div[msgId="${id[i]}"]`;
        $(sel).remove();
      }
}

// setInterval New Message
setInterval(function(){
  

if(!requestStatus)
{
     getMessages();
}

},1000);


// getMessage ajax request
function getMessages()
{
    requestStatus = true;
    let msgCount = $(".msg-container>*").length; 
   let lastMsgId = 0;

   if(msgCount != 0)
   {
      lastMsgId = $($(".msg-container>*")[0]).attr("msgId");
   }

    let data = {id:receiveId,msgId:lastMsgId};
       $.ajax({
     url:baseUrl+"get-msg",
     type:"post",
     data:data,
     success:function(data) 
     {
            if(data.status == "false" || data.status == "true")
            {
                seen(data.status);
                 requestStatus = false;
                 ImgClick();
                 $(".loader").hide();
                 return;
            }
            data.forEach((element,index)=>{
             if(element['sender_id'] != receiveId)
             {
                let HTML = SenderMessageHTML(element);
                $(".msg-container").prepend(HTML);
             }

             // user Recevie Message
             else{
               let HTML = ReceiveMessageHTML(element);
               $(".msg-container").prepend(HTML);
             }
             if(index == data.length-1)
             {
                 $(".loader").hide();
             }
       });
       requestStatus = false;
       ImgClick();
     },
     error:function(error) 
     {
        
     }
    });
}

function ImgClick()
{
  $("img").click(function(e) {
         if($(e.target).attr("src").match("assets/images"))
         {
              window.location.href = $(e.target).attr("src");
         }
});
}


function seen(status)
{
    if(status == "true")
    {
       $(".seen").css("display","block");
    }
    else{
       $(".seen").css("display","none");
    }
}




function SenderMessageHTML(msg)
{
     
     if(msg['msg_text'] != null)
     {
          return `
           <div class="sent-msg-box" msgId="${msg['id']}"  select="false" delete="-1">
           <div class="text-msg">
           ${msg['msg_text']}
           </div>
           <div class="time">${msg['time']}</div>
           <div class="overlay"></div>
           </div>
          `;
     }
     else{
       let MsgFile = msg['msg_file'].split("/")[0];

       let file = msg['msg_file'].split(".");
       
       let exFile = file[file.length-1];


       if(MsgFile == "images")
       {
           return `
           <div class="sent-msg-box" msgId="${msg['id']}"  select="false" delete="-1">
           <div class="msg-img">
            <img src="${baseUrl}assets/${msg['msg_file']}" alt="">
            </div>
           <div class="time">${msg['time']}</div>
           <div class="overlay"></div>
           </div>
          `;
       }
       else if(MsgFile == "videos")
       {
           return `
           <div class="sent-msg-box" msgId="${msg['id']}"  select="false" delete="-1">
           <video width="200" height="150" controls>
           <source src="${baseUrl}assets/${msg['msg_file']}" type="video/mp4">
          </video>
           <div class="time">${msg['time']}</div>
           <div class="overlay"></div>
           </div>
          `;
       }
       else if(MsgFile == "files")
       {
        let msgFileName = msg['msg_file'].replace("."+exFile,"");
        msgFileName = msgFileName.replace("files/","");
          return `
           <div class="sent-msg-box" msgId="${msg['id']}"  select="false" delete="-1">
           <div class="msg-file">
            <img src="${baseUrl}assets/icons/file.svg" alt=""><p>${msgFileName.slice(0,10)}.${exFile}</p><a href="${baseUrl}assets/${msg['msg_file']}" download><img src="${baseUrl}assets/icons/download.svg" alt=""></a>
        </div>
           <div class="time">${msg['time']}</div>
           <div class="overlay"></div>
           </div>
          `;
       }
       else if(MsgFile == "music")
       {
           return `
           <div class="sent-msg-box" msgId="${msg['id']}"  select="false" delete="-1">
           <audio  width="250px" controls>
           <source src="${baseUrl}assets/${msg['msg_file']}" type="audio/ogg">
           </audio>
           <div class="time">${msg['time']}</div>
           <div class="overlay"></div>
           </div>
          `;
       }
    }
}


function ReceiveMessageHTML(msg)
{
    if(msg['msg_text'] != null)
     {
          return `
           <div class="receive-msg-box" msgId="${msg['id']}"  select="false" delete="-1"  select="false" delete="-1">
           <div class="text-msg">
           ${msg['msg_text']}
           </div>
           <div class="time">${msg['time']}</div>
           <div class="overlay"></div>
           </div>
          `;
     }
     else{
       let MsgFile = msg['msg_file'].split("/")[0];

       let file = msg['msg_file'].split(".");
       
       let exFile = file[file.length-1];


       if(MsgFile == "images")
       {
           return `
           <div class="receive-msg-box" msgId="${msg['id']}"  select="false" delete="-1">
           <div class="msg-img">
            <img src="${baseUrl}assets/${msg['msg_file']}">
            </div>
           <div class="time">${msg['time']}</div>
           <div class="overlay"></div>
           </div>
          `;
       }
       else if(MsgFile == "videos")
       {
           return `
           <div class="receive-msg-box" msgId="${msg['id']}"  select="false" delete="-1">
           <video width="200" height="150" controls>
           <source src="${baseUrl}assets/${msg['msg_file']}" type="video/mp4">
          </video>
           <div class="time">${msg['time']}</div>
           <div class="overlay"></div>
           </div>
          `;
       }
       else if(MsgFile == "files")
       {
        let msgFileName = msg['msg_file'].replace("."+exFile,"");
        msgFileName = msgFileName.replace("files/","");
          return `
           <div class="receive-msg-box" msgId="${msg['id']}"  select="false" delete="-1">
           <div class="msg-file">
            <img src="${baseUrl}assets/icons/file.svg" alt=""><p>${msgFileName.slice(0,10)}.${exFile}</p><a href="${baseUrl}assets/${msg['msg_file']}" download><img src="${baseUrl}assets/icons/download.svg" alt=""></a>
            </div>
           <div class="time">${msg['time']}</div>
           <div class="overlay"></div>
           </div>
          `;
       }
       else if(MsgFile == "music")
       {
           return `
           <div class="receive-msg-box" msgId="${msg['id']}"  select="false" delete="-1">
           <audio controls width="250px">
           <source src="${baseUrl}assets/${msg['msg_file']}" type="audio/ogg">
           </audio>
           <div class="time">${msg['time']}</div>
           <div class="overlay"></div>
           </div>
          `;
       }
     }
}




});