$(document).ready(function()
{

$("#register form").submit(function(e){
          if(!registerFormValidation())
          	{
          		e.preventDefault();
          	}
});



function registerFormValidation()
{
	// user name Validation
    if($("input[name='name']").val().trim().length >= 3)
    {
    	// user mobile No validation
          if($("input[name='mobile']").val().trim().length == 10)
          {
          	   // Email Validation 
          	let Email = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
               if($("input[name='email']").val().toLowerCase().match(Email))
               {
                      // password validation
               	   let regularExpression  = /^[a-zA-Z0-9!@#$%^&*]{8,20}$/;

               	   if(regularExpression.test($("input[name='password']").val()))
               	   {
                       return true;
               	   }
               	   else{
               	   	Alert("password should contain atleast one number and one special character","warning");
               	   	return false;
               	   }
               }
               else{
               	    Alert("Check Email Id !!","warning");
    	           return false;
               }
          }
          else{
    	        Alert("Check Mobile No. !!","warning");
    	        return false;
           }
    }
    else{
    	Alert("Name length Min 3 Characters !!","warning");
    	return false;
    }
}

});