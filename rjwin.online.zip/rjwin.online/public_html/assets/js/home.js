$(document).ready(function()
{


  let requestStatus = true;

  let userId = $(".profile-img").attr("data");
  
setInterval(function(){
    if(requestStatus)
    {
      getHistory();
    }
},1000);




$(".logout").click(function()
{
   event.preventDefault();
   confirm("logout");
});





function getHistory()
{
  requestStatus = false;

  let msgBox = $(".user-box");

  let lastId = 0;

  if(msgBox.length != 0)
  {
        lastId = $(msgBox[0]).attr("msgid");
  }
  
 let data = {id:lastId};

  $.ajax({
     url:baseUrl+"get-history",
     type:"post",
     data:data,
     success:function(data) 
     {
         if(data.length == 0)
         {
          requestStatus = true;
          return;
         }
          let msgId = "";
          let HTML = "";
          let msg = "";
          let alert = "";
          data.forEach((element,index)=>{

            console.log()
               
               if(element.seen_status == 0 && element.sender_id != userId)
               {
                    alert = "active";
               }
               else{
                alert = "unactive";
               }

               if(element.sender_id == userId)
               {
                   msgId = element.receive_id;
               }
               else{
                msgId = element.sender_id;
               }

               if(element.msg_text == null)
               {
                     msg = element.msg_file;
               }
               else{
                     msg = element.msg_text;
               }
               HTML += `
               <a href="${baseUrl}chats/${msgId}">
                <div class="user-box" msgid="${element.id}">
                <div class="img-box">
                <img src="${baseUrl}assets/images/${element.profile_Img}" alt="">
                </div>
                <div class="name-msg">
                <p>${element.name}</p>
                <p>${msg.slice(0,15)}...</p>
                </div>
                <div class="alert-time">
                 <div class="time">${element.time}</div>
                <div class="alert ${alert}"></div>
                </div>
                </div>
                </a>
               `;
          });
          $("section").html(HTML);
          requestStatus = true;
     }
    });
}


});