$(document).ready(function()
{
     
    let searchInput = $("input")[0];

    let AllUser = $(".user-container a");

    searchInput.addEventListener("input",function()
    {
            let value = this.value.toLowerCase();

            Array.from(AllUser).forEach((element,index)=>{
            if(!$(element).attr("data").toLowerCase().match(value))
            {
                   $(element).hide();
            }
            else{
            	$(element).show();
            }
            });

    });

});