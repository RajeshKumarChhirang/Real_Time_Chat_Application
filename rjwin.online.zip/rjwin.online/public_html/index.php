<?php 
session_start();
require_once("../vendor/autoload.php");
require_once("../env.php");
require_once("../app/helper/view_helper.php");

$routes = new app\services\router();

$request_url = new app\request\request();

$routes->getHandle($request_url->get_request,$request_url->get_method);

?>