<?php 

namespace app\request;

class request
{
	public $get_request;
	public $get_method;
	public $get_product;

	public $matchURI;
	function __construct()
	{
		$this->get_request = str_replace(PUBLIC_DIR,"",$_SERVER['REQUEST_URI']);

		$this->get_product = ["confirm"=>"/confirm","update-password"=>"/update-password","chats"=>"/chats"];

		foreach ($this->get_product as $x => $y) {

        if(preg_match("/$x/i", $this->get_request))
        {
        	$this->get_request = $y;
        	break;
        }

        }

		$this->get_method = $_SERVER['REQUEST_METHOD'];
	}
}


 ?>