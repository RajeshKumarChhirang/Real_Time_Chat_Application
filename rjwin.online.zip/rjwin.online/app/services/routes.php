<?php 

use app\services\router;


// HomeController
router::AddRoutes("/","HomeController","index","GET");
router::AddRoutes("/login","HomeController","login","GET");
router::AddRoutes("/register","HomeController","register","GET");
router::AddRoutes("/forgot-password","HomeController","forgotLink","GET");
router::AddRoutes("/update-password","HomeController","updatePassword","GET");
router::AddRoutes("/profile","HomeController","profile","GET");
router::AddRoutes("/user","HomeController","user","GET");
router::AddRoutes("/chats","HomeController","chats","GET");
router::AddRoutes("/logout","HomeController","logout","GET");


// AdminController
router::AddRoutes("/register","AdminController","register","POST");
router::AddRoutes("/forgot-link","AdminController","forgotLink","POST");
router::AddRoutes("/change-password","AdminController","changePassword","POST");
router::AddRoutes("/update-profile","AdminController","updateProfile","POST");
router::AddRoutes("/send-text-msg","AdminController","sendTextMsg","POST");
router::AddRoutes("/send-file-msg","AdminController","sendFileMsg","POST");
router::AddRoutes("/get-msg","AdminController","getMsg","POST");
router::AddRoutes("/delete-msg","AdminController","deleteMsg","POST");
router::AddRoutes("/get-history","AdminController","getHistory","POST");

// AuthController
router::AddRoutes("/confirm","AuthController","confirmUserAccount","GET");
router::AddRoutes("/auth","AuthController","authLoginData","POST");




 ?>