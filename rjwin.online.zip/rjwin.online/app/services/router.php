<?php 

namespace app\services;

require_once("../app/services/routes.php");



class router
{
    private static $routes = array();

    public $is_Match = false;

    public $function_method;
  
	public static function AddRoutes($url,$controller,$function,$request_type)
	{
           self::$routes[] = [
               "url"=>$url,
               "controller"=>$controller,
               "method"=>$function,
               "request_type"=>$request_type
             ];
	}

	public function getRouter()
	{
		return self::$routes;
	}
  
	public function getHandle($get_Request,$get_Method)
	{
          foreach(self::$routes as $routes){
          	if($routes['url'] == $get_Request && $routes['request_type'] == $get_Method)
          	{       		
                $namespace_class = "app\controller\\".$routes['controller'];

                $function = $routes['method'];

                 $function_call = new $namespace_class();

                 $function_call->$function();

                 $this->is_Match = true;
          	}
          }
          if(!$this->is_Match)
          {
            randerView("error404");
          }
	}
}





 ?>