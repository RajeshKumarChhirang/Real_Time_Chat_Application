<?php 

namespace app\services;
use app\PHPMailer\src\PHPMailer;
use app\PHPMailer\src\SMTP;

class Email
{
	public function getEmail($send_to,$token)
	{
		$mail = new PHPMailer(true);

        $mail->isSMTP();

        $mail->SMTPAuth = true;

        $mail->SMTPSecure = "tls";

       $mail->Host = "smtp.gmail.com";

       $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;

       $mail->Port = 587;

       $mail->IsHTML(true);

        $mail->CharSet = 'UTF-8';

        $mail->Username = Email_Id;
        $mail->Password = Email_Password;

       // Your email ID and Email Title
       $mail->setFrom(Email_Id,Application_Name);

         $mail->addAddress($send_to);

         // You can change the subject according to your requirement!
         $mail->Subject = "Welcome !! ";
         // You can change the Body Message according to your requirement!
         $url = url;
         $mail->Body = "
          <a href=$url".$token."><button style='width:150px;border:none;background:blue;height:40px;color:#fff;cursor:pointer;'>Click Now</button></a>";
          $mail->send();
          return "Account Activation Link Sent Your Email Id. Check Your Email";
	}
}

 ?>