<?php 

namespace app\database;
use PDO;

class connection
{
	private $servername;
    private $username;
    private $password;
    private $DbName;
    private $conn;
	
	public function __construct()
	{
		 $this->servername = DB_SERVER_NAME;
         $this->username = DB_USERNAME;
         $this->password = DB_PASSWORD;
         $this->DbName = DB_DATABASE;

        // Connect Database

         $this->conn = new PDO("mysql:host=$this->servername;dbname=$this->DbName", $this->username, $this->password);
         $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}

    public function getConnection()
    {
         return $this->conn;
     }
}

$database = new connection();
 ?>