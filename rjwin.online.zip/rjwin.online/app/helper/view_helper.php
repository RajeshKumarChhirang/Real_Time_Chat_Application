<?php 

use app\controller\AuthController;

// require page function
function randerView($view_value,$value=array())
{
	require_once("../app/view/$view_value.php");
}

// redirect page function
function redirect($uri)
{
   header("Location:".url.$uri);
}

// check login status
function checkLoginStatus()
{
     if(isset($_COOKIE['MLIT']))
     {
	            $check = new AuthController();
		        $Status = $check->checkLoginStatus($_COOKIE['MLIT']);
		       if($check)
		      {
			     return true;
		      }
		      else{
			     return false;
		     }
	 }
	else{
		return false;
	}
}


function getUserId()
{
     if(isset($_COOKIE['MLIT']))
     {
	            $check = new AuthController();
		        return $check->getUserId($_COOKIE['MLIT']);
	 }
		         
}

function generateRandomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[random_int(0, $charactersLength - 1)];
    }
    return $randomString;
}



 ?>