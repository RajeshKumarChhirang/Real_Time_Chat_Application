<?php 
randerView("header",["title"=>"Register Now | ".Application_Name,"css"=>"login"]);
 ?>


<div class="login-container" id="register">
  <div class="form-container">
    <form action="<?=url;?>register" method="post">
      <h1>Create New Account</h1>
      <label for="name">
        Name
      </label>
      <input type="text" name="name" id="name">
      <label for="mobile">
        Mobile No.
      </label>
      <input type="text" name="mobile" id="mobile" maxlength="10">
      <label for="email">
        Email Id
      </label>
      <input type="text" name="email" id="email">
      <div class="input-box">
        <label for="password">
        Password
      </label>
      <input type="password" name="password" id="password">
      <img src="<?=url?>assets/icons/eye.svg" class="show-icon" data="hide">
      </div>
      <button>Register Now</button>
      <p>Already have an account? <a href="login">Login Now</a></p>
    </form>
  </div>
</div>

 <?php 
randerView("footer",["js"=>"register"]);
  ?>