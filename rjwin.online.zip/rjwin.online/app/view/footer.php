<script>
  let baseUrl = "<?=url;?>";
</script>
<script src="<?=url;?>assets/js/app.js"></script>
<?php 

if(isset($value['js']))
{
	$js = $value['js'];
	$url = url;
	echo "<script src='".$url."assets/js/$js.js'></script>";
}

if(isset($_SESSION['msg']) && isset($_SESSION['icon']))
{
  $msg = $_SESSION['msg'];
  $icon = $_SESSION['icon'];
  echo "<script>Alert('$msg','$icon');</script>";
  unset($_SESSION["msg"]);
  unset($_SESSION["icon"]);
}

 ?>
</body>
</html>