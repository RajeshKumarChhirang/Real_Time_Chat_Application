<?php
 randerView("header",["title"=>"Page Not Found | ".Application_Name]);
?>


<div class="error" style="display:flex;flex-direction:column;gap:20px;height:90vh;justify-content:center;align-items:center;">
	<img src="<?=url;?>assets/icons/error.png" alt="" style="width:300px">
    <a href="<?=url;?>"><button style="background: none;border:1px solid lightgray;padding: 10px 20px;cursor: pointer;">Go To Home</button></a>
</div>

<?php
randerView("footer");
?>