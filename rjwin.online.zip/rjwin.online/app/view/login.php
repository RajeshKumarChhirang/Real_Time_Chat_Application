<?php 
randerView("header",["title"=>"Login Now | ".Application_Name,"css"=>"login"]);
 ?>


<div class="login-container" id="login">
  <div class="form-container">
    <form action="<?=url;?>auth" method="post">
      <h1>Login</h1>
      <label for="username">
        Email or Mobile Number
      </label>
      <input type="text" name="username" id="username">
      <div class="input-box">
        <label for="password">
        Password
      </label>
      <input type="password" name="password" id="password">
      <img src="<?=url?>assets/icons/eye.svg" class="show-icon" data="hide">
      </div>
      <a href="<?=url;?>forgot-password" class="forgot">Forgot Password</a>
      <button>Login Now</button>
      <p>Dont't have an account? <a href="register">Register Now</a></p>
    </form>
  </div>
</div>


 <?php 
      randerView("footer");
  ?>