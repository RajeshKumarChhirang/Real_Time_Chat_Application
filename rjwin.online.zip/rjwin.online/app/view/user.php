<?php 
use app\controller\AuthController;
$data = new AuthController();
$userId = getUserId();
$getUserData = $data->checkDataAndGetValue("user","user_Id",$userId,"profile_Img");
randerView("header",["title"=>"User | ".Application_Name,"css"=>"user"]);

$All_user = $data->checkDataMultipalConditionAndGetMultiplaValue("user","user_Id != '$userId'","*");

 ?>
 <header>
   <div class="logo-btn">
     <div class="back-btn">
       <img src="<?=url;?>assets/icons/back.svg">
     </div>
     <p>New conversation</p>
   </div>
 </header>
 <div class="search-container">
   <p>To:</p>
   <input type="text" placeholder="Type names or phone numbers" autofocus>
 </div>
 <div class="user-container">
  <?php 

foreach ($All_user as $key => $value) {
  
   ?>
   <a href="<?=url;?>chats/<?=$value['user_Id'];?>" data="<?=$value['name'];?>-<?=$value['mobile_No'];?>">
    <div class="user-box">
     <div class="img-box">
       <img src="<?=url;?>assets/images/<?=$value['profile_Img'];?>" alt="">
     </div>
     <div class="name-number">
       <p><?=$value['name'];?></p>
       <p><?=$value['mobile_No'];?></p>
     </div>
   </div>
 </a>
<?php }; ?>
 </div>
 <?php 
     randerView("footer",["js"=>"user"]);
  ?>