<?php
randerView("header",["title"=>"Forgot Password | ".Application_Name,"css"=>"login"]);
 ?>



<div class="login-container" id="forgot-link">
  <div class="form-container">
    <form action="<?=url;?>forgot-link" method="post">
      <h1>Forgot Password</h1>
      <label for="username">
        Email
      </label>
      <input type="text" name="username" id="username">
      <button>Sent Links</button>
      <p>Already have an account? <a href="login">Login Now</a></p>
    </form>
  </div>
</div>


 <?php 
randerView("footer");
  ?>