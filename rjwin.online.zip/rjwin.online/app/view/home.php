<?php 


use app\controller\AuthController;


$data = new AuthController();


$userId = getUserId();

$user_Details = $data->checkDataAndGetValue("user","user_Id","$userId","profile_Img,user_Id");
randerView("header",["title"=>Application_Name]);
 ?>


 <header>
   <div class="logo">
     <h1>
       <?=Application_Name;?>
     </h1>
   </div>
   <div class="icon">
     <a href="<?=url;?>profile">
       <img src="<?=url?>assets/images/<?=$user_Details['profile_Img'];?>" alt="" class="profile-img" data="<?=$user_Details['user_Id'];?>">
     </a>
     <a href="<?=url;?>logout">
       <img src="<?=url?>assets/icons/logout.svg" alt="" title="logout" class="logout">
     </a>
   </div>
 </header>
 <section>
 </section>
 <div class="new-chats">
  <a href="<?=url;?>user">
    <img src="<?= url;?>assets/icons/new-chats.svg"></a>
</div>

 <?php 
randerView("footer",["js"=>"home"]);
  ?>