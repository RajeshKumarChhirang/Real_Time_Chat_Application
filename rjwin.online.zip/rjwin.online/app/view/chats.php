<?php

use app\controller\AuthController;

$data = new AuthController();

$id = $value['id'];

$userData = $data->checkDataAndGetValue("user","user_Id",$id,"*");
randerView("header",["title"=>$userData['name']." | ".Application_Name,"css"=>"chats"]);

 ?>


<header>
	<div class="name-btn">
		<div class="back-btn">
			<img src="<?=url;?>assets/icons/back.svg" alt="">
		</div>
		<div class="name-box">
        <div class="img-box">
        	<img src="<?=url;?>assets/images/<?=$userData['profile_Img'];?>" alt="" data="<?=$userData['user_Id'];?>" class="profile-img">
        </div>
        <div class="name">
        	<p><?=$userData['name'];?></p>
        	<p><?=$userData['mobile_No'];?></p>
        </div>
		</div>
	</div>
	<div class="icons">
		<img src="<?=url;?>assets/icons/delete.svg" alt="" class="delete">
		<img src="<?=url;?>assets/icons/select.svg" class="select">
	</div>
</header>

<div class="msg-container" selectData="false">
	
</div>
<div class="seen">
		<p>seen</p>
	</div>
<div class="sent-container">
<div class="sent-input">
	<input type="text" placeholder="Type Your Message">
	<div class="img-sent">
		<img src="<?=url;?>assets/icons/image.svg" alt="">
		<form action="" class="file-form">
		<input type="file" name="file[]" multiple>
	  </form>
	</div>
	<img src="<?=url;?>assets/icons/send.svg" alt="" class="sent-msg">
</div>
</div>
<div class="loader">
	<div class="loading"></div>
</div>
 <?php 

randerView("footer",["js"=>"chats"]);

  ?>