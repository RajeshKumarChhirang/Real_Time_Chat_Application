<?php
randerView("header",["title"=>"Forgot Password | ".Application_Name,"css"=>"login"]);
 ?>



<div class="login-container" id="update-password">
  <div class="form-container">
    <form action="<?=url;?>change-password" method="post">
      <h1>Change Password</h1>
      <label for="password">
        Password
      </label>
      <input type="password" name="password" id="password">
      <button>Update Password</button>
      <p>Already have an account? <a href="login">Login Now</a></p>
    </form>
  </div>
</div>


 <?php 
randerView("footer");
  ?>