<?php 
         use app\controller\AuthController;
         $userId = explode(",",$_COOKIE['MLIT'])[0];

         $auth = new AuthController();

         $userData = $auth->checkDataAndGetValue("user","user_Id",$userId,"*");

        randerView("header",["title"=>$userData['name']." | ".Application_Name,"css"=>"login"]);
 ?>
<div class="back-btn">
  <img src="<?=url;?>assets/icons/back.svg" alt="back-btn">
</div>
<div class="login-container" id="profile">
    <div class="form-container">
    <form action="<?=url;?>update-profile" method="post" enctype="multipart/form-data">
      <h1>User Profile</h1>
      <div class="user-profile">
      	<div class="img-box">
      		<img src="<?=url;?>assets/images/<?=$userData['profile_Img'];?>" alt="user-icon" class="user-img" id="displayImage">
      		<img src="<?=url;?>assets/icons/edit.svg" alt="edit-icon" class="change-icon">
          <input type="file" accept="image/*" name="user-profile-img">
      	</div>
      </div>
      <label for="name">
        Name
      </label>
      <input type="text" name="name" id="name" value="<?=$userData['name'];?>">
      <label for="mobile">
        Mobile No.
      </label>
      <input type="text" name="mobile" id="mobile" maxlength="10" value="<?=$userData['mobile_No'];?>" disabled>
      <label for="email">
        Email Id
      </label>
      <input type="text" name="email" id="email" value="<?=$userData['email_Id'];?>" disabled>
      <div class="input-box">
        <label for="password">
        Password
      </label>
      <input type="password" name="password" id="password" value="<?=$userData['password'];?>">
      <img src="<?=url?>assets/icons/eye.svg" class="show-icon" data="hide">
      </div>
      <button>Update Profile</button>
    </form>
  </div>
</div>

 <?php 
randerView("footer",["js"=>"profile"]);
  ?>