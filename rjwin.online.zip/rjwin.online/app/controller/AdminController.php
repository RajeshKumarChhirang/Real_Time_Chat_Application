<?php 

namespace app\controller;

use app\database\connection;
use app\controller\InsertDataController;
use app\controller\AuthController;
use app\services\Email;
use PDO;

class AdminController
{
	private $database;
	private $data;
	public function __construct()
	{
           $this->database = new connection();
           $this->data = new InsertDataController();
           $this->auth = new AuthController();
           $this->email = new Email();
	}

	// user Register Data
	public function register()
	{
		$name = $_POST['name'];
		$mobile = $_POST['mobile'];
		$email = strtolower($_POST['email']);
		$password = $_POST['password'];
		$user_Id = generateRandomString(15);
		$link_Tokan = generateRandomString(20);
 
                  date_default_timezone_set("Asia/Calcutta");
			
			$time = date("h:iA d-M-y");
            // check Data Already Register
			if(!$this->auth->checkData("user","email_Id",$email))
			{
				if(!$this->auth->checkData("user","mobile_No",$mobile))
				 {
				  $data = $this->auth->checkDataAndGetValue("user","email_Id",$email,"login_Status,link_Tokan");
					if($data['login_Status'] == 0)
					{
                        $getEmail = $this->email->getEmail($email,"confirm?email=$email&&id=".$data['link_Tokan']);
                        $_SESSION['msg'] = $getEmail;
                        $_SESSION['icon'] = "success";
                        redirect("login");
                        exit();
					}
					$_SESSION['msg'] = "Email And Mobile Number Already Register !!";
				    $_SESSION['icon'] = "error";
				    redirect("register");
				    exit();
				}
				$_SESSION['msg'] = "Email Id Already Register !!";
				$_SESSION['icon'] = "error";
				redirect("register");
				exit();
			}
			else
			{
				 if(!$this->auth->checkData("user","mobile_No",$mobile))
				 {
                    $_SESSION['msg'] = "Mobile Number Already Register !!";
				    $_SESSION['icon'] = "error";
				    redirect("register");
				    exit();
				}
			}

		$sql = "INSERT INTO user(name,mobile_No,email_Id,password,user_Id,create_at,link_Tokan) VALUES ('$name', '$mobile', '$email','$password','$user_Id','$time','$link_Tokan')";

		// Call Insert Data Function 
		$this->data->InsertRegisterData($sql,$email,$link_Tokan);
	}

	public function forgotLink()
	{
		$email = $_POST['username'];
        
        if(!$this->auth->checkData("user","email_Id",$email))
        {
        	            $forgot_Tokan = generateRandomString(20);
        	            $this->data->updateMultipalData("user","email_Id",$email,"forgot_Tokan= '$forgot_Tokan'");
                        $getEmail = $this->email->getEmail($email,"update-password?email=$email&&id=".$forgot_Tokan);
                        $_SESSION['msg'] = "Email Successfully Sent !! Please Check Your Email And Change Your Password.";
                        $_SESSION['icon'] = "success";
                        redirect("login");
                        exit();
        }
                        $_SESSION['msg'] = "Email Id Not Found !! Check Your Email Id";
                        $_SESSION['icon'] = "error";
                        redirect("forgot-password");
	}
	public function changePassword()
	{
		if(isset($_SESSION['M_Email']))
		{
                    $email = $_SESSION['M_Email'];
                    $password = $_POST["password"];
                    $this->data->updateData("user","email_Id",$email,"password",$password);
                    unlink($_SESSION['M_Email']);
                        $_SESSION['msg'] = "Password is Changed Successfully !! Login Now.";
                        $_SESSION['icon'] = "success";
                        redirect("login");
                        exit();
		}
		redirect("error");
	}
	public function updateProfile()
	{
		$img = time()."-".$_FILES['user-profile-img']['name']; //change
		
		$Tmp_name = $_FILES['user-profile-img']['tmp_name'];
		$imgType = str_replace("image/","",$_FILES['user-profile-img']['type']);
		$name = $_POST['name'];
		$password = $_POST['password'];

		date_default_timezone_set("Asia/Calcutta");
			
			$time = date("h:iA d-M-y");

		if($imgType == "jpeg" || $imgType == "png" || $imgType == "jpg" || $imgType == "webp" || $imgType == "")
		{
			if(strlen($name) >= 3)
			{
                               if(strlen($password) >= 8)
                               {
                                       if($imgType != "")
                                       {
                                       	   if($this->data->singleUpload("assets/images/",$img,$Tmp_name))
                                       	   {
                                       	       // change
                                       	   	$id = getUserId();
                                       	   	$prev = $this->auth->selectOneData("user","WHERE user_Id = '$id'","profile_Img");

                                       	   	if($prev['profile_Img'] != "user.svg")
                                       	   	{
                                       	   		unlink("assets/images/".$prev['profile_Img']);
                                       	   	}
                                       	   	// change
                                       	   	
                                       	   	$this->data->updateMultipalData("user","user_Id",getUserId(),"name='$name',password='$password',profile_Img='$img',update_at='$time'");
                                       	   	$_SESSION['msg'] = "Your Profile Is Updated !!";
                                                $_SESSION['icon'] = "success";
                                                redirect("profile");
                                                exit();
                                       	   }
                                       	  $_SESSION['msg'] = "Something Is Wrong !! Please Try Again.";
                                          $_SESSION['icon'] = "warning";
                                          redirect("profile");
                                          exit();
                                       }
                                                $this->data->updateMultipalData("user","user_Id",getUserId(),"name='$name',password='$password',update_at='$time'");
                                                $_SESSION['msg'] = "Your Profile Is Updated !!";
                                                $_SESSION['icon'] = "success";
                                                redirect("profile");
                                                exit();
                               }
                               $_SESSION['msg'] = "Password Length 8-20 digits !!";
                                $_SESSION['icon'] = "warning";
                               redirect("profile");
                               exit();
			}
			else{
				$_SESSION['msg'] = "Name length Min 3 Characters !!";
                                $_SESSION['icon'] = "warning";
                               redirect("profile");
                               exit();
			}
		}
		        $_SESSION['msg'] = "Image Formate Not Supported !! Please Select Another Images";
                        $_SESSION['icon'] = "error";
                        redirect("profile");
                        exit();
	}
	public function sendTextMsg()
	{

		if(!checkLoginStatus())
		{
                      exit();
		}
		$receiveId = $_POST['id'];

		$senderId = getUserId();

		$msg = $_POST['text'];



		        date_default_timezone_set("Asia/Calcutta");
			
			$time = date("h:iA d-M-y");


			if($this->data ->insertData("message","sender_id,receive_id,msg_text,time","'$senderId','$receiveId','$msg','$time'"))
			{
                              echo true;
			}
	}

	public function sendFileMsg()
	{

		if(!checkLoginStatus())
		{
                      exit();
		}

		$receiveId = $_POST['id'];

		$senderId = getUserId();
		$files = count($_FILES['file']['name']);

		date_default_timezone_set("Asia/Calcutta");
			
			$time = date("h:iA d-M-y");

		$fileType = ["image"=>"images","audio"=>"music","application"=>"files","video"=>"videos"];

		for ($i=0; $i < $files; $i++) { 

		   foreach ($fileType as $x => $y) {

                   if(preg_match("/$x/i",$_FILES['file']['type'][$i]))
                  {
                  	$nameFile = time()."-".$_FILES['file']['name'][$i]; //change
                  	
                  	$tmpNameFile = $_FILES['file']['tmp_name'][$i];
                       

                       if(!$this->auth->checkData("message","msg_file","$y"."/".$nameFile))
                       {
                              $nameFile = $nameFile.time();
                       }

        	         if($this->data->singleUpload("assets/$y/",$nameFile,$tmpNameFile))
        	        {
                             $nameFile = $y."/".$nameFile;
                             if($this->data ->insertData("message","sender_id,receive_id,msg_file,time","'$senderId','$receiveId','$nameFile','$time'"))
                             {
                                        break;
                             }
        	        }
        	        
                  }

                  }
		}
		
	}
	public function getMsg()
	{
		if(!checkLoginStatus())
		{
			exit();
		}
		$receiveId = $_POST['id'];
		$senderId = getUserId();
		$lastMsgId = $_POST['msgId'];


       $lastmsg = $this->auth->selectOneData("message","ORDER BY id DESC LIMIT 1","id");


       if(empty($lastmsg))
       {
       	            header('Content-Type: application/json; charset=utf-8');
               	  	$seenStatus['status'] = "false";
               	  	echo json_encode($seenStatus);
               	  	exit();
       }
        $id = $lastmsg['id'];



		$changeSeen = $this->auth->selectOneData("message","WHERE receive_id = '$senderId' AND id = $id","id");

		if(!empty($changeSeen))
		{
               $this->data->updateData("message","id",$changeSeen['id'],"seen_status","1");
		}
                
                $msg_records = $this->auth->checkDataMultipalConditionAndGetMultiplaValue("message","sender_id IN('$senderId','$receiveId') AND receive_id IN ('$senderId','$receiveId') AND id>'$lastMsgId'","*");

               
               if(empty($msg_records))
               { 
               	$seen = $this->auth->selectOneData("message","WHERE sender_id = '$senderId' AND seen_status = 1 AND id = $id","id");
                  $seenStatus = array();

               	  if(!empty($seen))
               	  {
               	  	header('Content-Type: application/json; charset=utf-8');
               	  	$seenStatus['status'] = "true";
               	  	echo json_encode($seenStatus);
               	  	exit();
               	  }
               	  else{
               	  	header('Content-Type: application/json; charset=utf-8');
               	  	$seenStatus['status'] = "false";
               	  	echo json_encode($seenStatus);
               	  	exit();
               	  }
               	  
               }


		        header('Content-Type: application/json; charset=utf-8');

                 echo json_encode($msg_records);
	}

	public function deleteMsg()
	{
		if(!checkLoginStatus())
		{
              exit();
		}
	    	$id = $_POST['Id'];
	    	$record = $this->auth->checkDataMultipalConditionAndGetMultiplaValue("message","id IN ($id) AND msg_text IS NULL","msg_file");
          	    if($this->auth->deleteDataMultipal("message","id",$id))
	    {
              foreach ($record as $key => $value) {
	    		unlink("assets/".$value[0]);
	    }
	    	echo true;
	     }
	}
	public function getHistory()
	{
		if(!checkLoginStatus())
		{
             exit();
		}
        $userId = getUserId();

        $lastId = $_POST['id'];


       // All msg Record sender and receive id

       $record = $this->auth->checkDataMultipalConditionAndGetMultiplaValue("message","sender_id = '$userId' OR receive_id = '$userId'","sender_id,receive_id,id");

        $length = count($record);

       if($lastId == $record[$length-1]['id'])
       {
       	  header('Content-Type: application/json; charset=utf-8');

           echo json_encode(array());
       	   exit();
       }
      
     //  To separate sender and recive id

       $msgIds = array();

       foreach (array_reverse($record) as $key => $value) {

       	if($value['sender_id'] == $userId)
       	{
                 if(!in_array($value['receive_id'],$msgIds))
                {
                     $msgIds[] = $value['receive_id'];
                }
       	}
       	else{
       		 if(!in_array($value['sender_id'],$msgIds))
                {
                     $msgIds[] = $value['sender_id'];
                }
       	}
       }
      
     // separate ids get name and profile images

       $userMsgName = array();

       foreach ($msgIds as $value) {
       	$userMsgName[] = $this->auth->checkDataAndGetValue("user","user_Id",$value,"name,profile_Img");
       }
       

     // // separate ids get last msg

       $userLastMsg = array();
       foreach ($msgIds as $value) {
       	$userLastMsg[] = $this->auth->selectOneData("message","WHERE sender_id IN ('$userId','$value') AND receive_id IN ('$userId','$value') ORDER BY id DESC LIMIT 1","*");
       }

       // get last msg array push name and profile images
       
       foreach ($userLastMsg as $key => $value) {

       	   $userLastMsg[$key]['name'] = $userMsgName[$key]['name'];
       	   $userLastMsg[$key]['profile_Img'] = $userMsgName[$key]['profile_Img'];
       }

                header('Content-Type: application/json; charset=utf-8');

                 echo json_encode($userLastMsg);
    }
}



 ?>