<?php 

namespace app\controller;

use app\database\connection;
use app\controller\AuthController;
use PDO;

class HomeController
{
	private $database;
	public function __construct()
	{
           $this->database = new connection();
           $this->data = new AuthController();
	}
	// this is HomePage Function
	public function index()
	{
		if(checkLoginStatus())
		{
     		randerView("home");
     		exit();
		}
     		redirect("login");
	}

	// this is Login Page Function
	public function login()
	{
		if(checkLoginStatus())
		{
     		redirect("");
     		exit();
		}
     		randerView("login");
	}

	// this is Register Page Function
	public function register()
	{
		if(checkLoginStatus())
		{
     		redirect("");
     		exit();
		}
		randerView("register");
	}

	//this is forgot password sent link page function

	public function forgotLink()
	{
		if(checkLoginStatus())
		{
     		redirect("");
     		exit();
		}
     		randerView("forgot");
	}

	// this is update password page function

	public function updatePassword()
	{
		if(checkLoginStatus())
		{
     		redirect("");
     		exit();
		}
		if(!isset($_GET['email']) && !isset($_GET['id']))
		{
              redirect("error");
     		  exit();
		}
		    $_SESSION['M_Email'] = $_GET['email'];
     		randerView("update-password");
	}
	public function profile()
	{
		if(checkLoginStatus())
		{
			randerView("profile");
			exit();
		}
		redirect("login");
	}
	public function user()
	{
		if(checkLoginStatus())
		{
			randerView("user");
			exit();
		}
		redirect("login");
	}
	public function chats()
	{
	    $userId = str_replace("chats/","",$_GET['url']);

	    if(!checkLoginStatus())
	    {
	    	redirect("login");
	    	exit();
	    }

	    if(getUserId() == $userId)
	    {
	    	redirect("error");
	    	exit();
	    }
	    if($this->data->checkData("user","user_Id",$userId))
	    {
	    	redirect("error");
	    	exit();
	    }
	    randerView("chats",["id"=>$userId]);
	}
	public function logout()
	{
        setcookie("MLIT", "", time() - 3600,"/");
        redirect("login");
	}

}


 ?>