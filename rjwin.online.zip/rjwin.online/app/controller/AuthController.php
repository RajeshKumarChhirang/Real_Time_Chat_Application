<?php 

namespace app\controller;

use app\database\connection;
use app\controller\InsertDataController;
use PDO;

class AuthController
{
	private $database;
	public function __construct()
	{
           $this->database = new connection();
           $this->data = new InsertDataController();
	}
	public function checkData($table,$whereCol,$whereVal)
	{
		$conn = $this->database->getConnection();
		$data = "SELECT * FROM $table WHERE $whereCol = '$whereVal'";
       $data_record = $conn->query($data)->fetch();
       if(empty($data_record))
       {
       	   return true;
       }
       return false;
	}

	public function checkDataMultipal($table,$whereColAndValue)
	{ 
		$conn = $this->database->getConnection();
		$data = "SELECT * FROM $table WHERE $whereColAndValue";
       $data_record = $conn->query($data)->fetch();
       if(empty($data_record))
       {
       	   return true;
       }
       return false;
	}

	public function checkDataAndGetValue($table,$whereCol,$whereVal,$getVal)
	{
		$conn = $this->database->getConnection();
		$data = "SELECT $getVal FROM $table WHERE $whereCol = '$whereVal'";
        $data_record = $conn->query($data)->fetch();
       return $data_record;
	}
    public function selectOneData($table,$whereColAndVal,$getVal)
    {
    	$conn = $this->database->getConnection();
		$data = "SELECT $getVal FROM $table $whereColAndVal";
		// echo "<br>".$data."<br>";
        $data_record = $conn->query($data)->fetch();
       return $data_record;
    }
   public function checkDataMultipalConditionAndGetValue($table,$whereColAndVal,$getVal)
	{
		$conn = $this->database->getConnection();
		$data = "SELECT $getVal FROM $table WHERE $whereColAndVal";
        $data_record = $conn->query($data)->fetch();
       return $data_record;
	}

	public function checkDataMultipalConditionAndGetMultiplaValue($table,$whereColAndVal,$getVal)
	{
		$conn = $this->database->getConnection();
		$data = "SELECT $getVal FROM $table WHERE $whereColAndVal";
        $data_record = $conn->query($data)->fetchAll();
       return $data_record;
	}

	public function seen($table,$whereColAndVal,$getVal)
	{
		$conn = $this->database->getConnection();
		$data = "SELECT $getVal FROM $table $whereColAndVal";
        $data_record = $conn->query($data)->fetch();
       return $data_record;
	}

	public function deleteDataMultipal($table,$whereCol,$whereVal)
	{
		$conn = $this->database->getConnection();
		$sql = "DELETE FROM $table WHERE $whereCol IN ($whereVal)";
		$conn->exec($sql);
		return true;
	}

	public function confirmUserAccount()
	{
	     	if(!$this->checkDataMultipal("user","link_Tokan='".$_GET['id']."' AND email_Id='".$_GET['email']."'"))
			{
				$getData = $this->checkDataAndGetValue("user","link_Tokan",$_GET['id'],"login_Status");
				if(!$getData["login_Status"])
				{
					$this->data->updateData("user","link_Tokan",$_GET['id'],"login_Status",1);
					    $_SESSION['msg'] = "Your Account has been Activated Successfully !! Go To Login Now";
                        $_SESSION['icon'] = "success";
                        redirect("login");
                        exit();
				}
				else{
					    $_SESSION['msg'] = "Your Account Already Active !!";
                        $_SESSION['icon'] = "success";
                        redirect("login");
                        exit();
				}
			}
			else{
				redirect("error404");
			}
	}
	public function authLoginData()
	{
		$username = $_POST['username'];
		$password = $_POST['password'];

		$record = $this->checkDataMultipalConditionAndGetValue("user","(email_Id='$username' OR mobile_No='$username') AND password = '$password'","id");
		if(!empty($record))
		{
             $genrate_login_tokan = generateRandomString(40);
             $this->data->updateMultipalData("user","id",$record['id'],"login_Tokan = '$genrate_login_tokan'");
             $userId = $this->checkDataAndGetValue("user","id",$record['id'],"user_Id");
             setcookie("MLIT",$userId['user_Id'].",$genrate_login_tokan", time() + (86400 * 30), "/");
             redirect("");
             exit();
		}
		else{
			if(!$this->checkDataMultipal("user","email_Id='$username' OR mobile_No='$username'"))
			{
                        $_SESSION['msg'] = "Wrong Password !! Please Check Your Password";
                        $_SESSION['icon'] = "error";
                        redirect("login");
                        exit();

			}
			else{
                       $_SESSION['msg'] = "Wrong Email Id !! Please Check Your Email Id";
                        $_SESSION['icon'] = "error";
                        redirect("login");
                        exit();
			}
		}
	}
	public function checkLoginStatus($userIdAndTokan)
	{
         $data = explode(",",$userIdAndTokan);
         return $this->checkDataMultipal("user","user_Id = '$data[0]' AND login_Tokan = '$data[1]'");
	}
	public function getUserId($userIdAndTokan)
	{
		 return explode(",",$userIdAndTokan)[0];
	}
}


 ?>