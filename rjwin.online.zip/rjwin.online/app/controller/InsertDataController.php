<?php 

namespace app\controller;

use app\database\connection;
use app\services\Email;
use PDO;

class InsertDataController
{
	private $database;
	private $email;
	public function __construct()
	{
           $this->database = new connection();
           $this->email = new Email();
	}
    
    // Add New User
	public function InsertRegisterData($sql,$email,$token)
	{
           $conn = $this->database->getConnection();
           $conn->exec($sql);
           $getEmail = $this->email->getEmail($email,"confirm?email=$email&&id=".$token);
           $_SESSION['msg'] = $getEmail;
           $_SESSION['icon'] = "success";
           redirect("login");
	}

    public function insertData($table,$InsertCol,$insertVal)
    	{
    		  $sql ="INSERT INTO $table($InsertCol) VALUES ($insertVal)";
              $conn = $this->database->getConnection();
               $conn->exec($sql);
               return true;
    	}

    	public function singleUpload($path,$imageName,$imagesTmpName)
    	{
    		$target_dir = $path;

    		$target_file = $target_dir . basename($imageName);
            
            if(move_uploaded_file($imagesTmpName,$target_file))
            	{
            		return true;
            	}
            	return false;

    	}

	public function updateData($table,$WhereCol,$WhereVal,$updateCol,$updateVal)
	{
		$conn = $this->database->getConnection();
		$sql = "UPDATE $table SET $updateCol='$updateVal' WHERE $WhereCol='$WhereVal'";

       $stmt = $conn->prepare($sql);

      $stmt->execute();
	}
	public function updateMultipalData($table,$WhereCol,$WhereVal,$updateColAndVal)
	{
		    $conn = $this->database->getConnection();
		    $sql = "UPDATE $table SET $updateColAndVal WHERE $WhereCol='$WhereVal'";
        $stmt = $conn->prepare($sql);
       $stmt->execute();
	}

	public function updateMultipalDataMultipalCon($table,$WhereColAndVal,$updateColAndVal)
	{
		    $conn = $this->database->getConnection();
		    $sql = "UPDATE $table SET $updateColAndVal WHERE $WhereColAndVal";
        $stmt = $conn->prepare($sql);
       $stmt->execute();
	}
}
