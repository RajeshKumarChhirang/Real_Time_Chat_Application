<?php

// Define Application Name
define("Application_Name","Messager");

// define Folder Name
define("Folder_Name", "/rjwin.online");

// Define Domain Name
define("PUBLIC_DIR",Folder_Name."/public_html");

define("url",$_SERVER['REQUEST_SCHEME']."://".$_SERVER['SERVER_NAME'].PUBLIC_DIR."/");

// Define Database Server Name
define("DB_SERVER_NAME","localhost");

// Define Database username
define("DB_USERNAME","root");

// Define Database Password
define("DB_PASSWORD","");

// Define Email Id
define("Email_Id","rajachoudhary3272@gmail.com");

// Define Email Password
define("Email_Password","kdho wgwu icvg wipe");

// Define Database Name
define("DB_DATABASE","chats_application");